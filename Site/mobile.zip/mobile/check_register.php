<?php
	error_reporting(0);
	session_start();
	
	$link = mysql_connect('localhost','root','root');
	mysql_select_db('mobile',$link);
	
	$errors = $ret = array();
	
	extract($_POST);
	
	if(!$username) {
		$errors[] = "Username is required";
	} else {
		$sql = "SELECT * FROM users WHERE username = '$username' LIMIT 1";
		$query = mysql_query($sql) or die(mysql_error());
		if(mysql_num_rows($query)) {
			$errors[] = "This username already exist";
		}
	}
	
	if(!$email) {
		$errors[] = "Email is required";
	} else {
		if(eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)) {
			$sql = "SELECT * FROM users WHERE email = '$email' LIMIT 1";
			$query = mysql_query($sql) or die(mysql_error());
		}else{
			$errors[] = "Not a valid Email Ex: user@something.com";
		}
		if(mysql_num_rows($query)) {
			$errors[] = "This email already exist";
		}
	}
	
	if(!$password) {
		$errors[] = "Password is required";
	} else {		
		if(!$repassword) {
			$errors[] = "Please re-type your password";
		}
	}
	
	if($password && $repassword && ($password != $repassword)) {
		$errors[] = "Passwords do not match";
	}
	
	if($errors) {
		$ret['error'] = implode('<br>',$errors);
	} else {
		$ret['success'] = true;
	}
	
	echo json_encode($ret);
	exit;
?>