<?php
	error_reporting(0);
	session_start();
	
	$link = mysql_connect('localhost','root','root');
	mysql_select_db('mobile',$link);
	
	$errors = $ret = array();
	
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	if(!$email) {
		$errors[] = "Email is required";
	}
	
	if(!$password) {
		$errors[] = "Password is required";
	}
	
	if(!$errors) {
		$password = md5($password);
		$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password' LIMIT 1";
		$query = mysql_query($sql) or die(mysql_error());
		if(mysql_num_rows($query)) {
			$ret['success'] = true; 
		} else {
			$ret['error'] = 'This is not a valid login.';
		}
	} else {		
		$ret['error'] = implode('<br>',$errors);
	}
	
	echo json_encode($ret);
	exit;
?>