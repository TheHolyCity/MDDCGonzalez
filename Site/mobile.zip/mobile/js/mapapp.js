$(document).ready(function(){
	
	$.mobile.ajaxEnabled = false;
	
	var lng = '';
	var lat = '';
	
	function initialize() {
		getLocation();	
	}
	// Gets Users Current Location
	function getLocation(){
		if (navigator.geolocation){	
			navigator.geolocation.getCurrentPosition(showPosition);
		}
	}
	
	function showPosition(position){
	  	 position.coords.latitude;
	  	 position.coords.longitude;
	}
	// Sets latitude  and longitude to a variable
	function showPosition(position){
		
		lat = position.coords.latitude;
	  	lng = position.coords.longitude;
	// Google Maps API v3 options center: for map centering location / Zoom: For zoom level / MapTypeId: for map view type
	  	
	    var mapOptions = {
	      center: new google.maps.LatLng(lat,lng),
	      zoom: 18,
	      mapTypeId: google.maps.MapTypeId.ROADMAP
	    };
	    
	    var map = new google.maps.Map(document.getElementById("map_canvas"),
	        mapOptions);
		
		var marker = new google.maps.Marker({    
	       position: new google.maps.LatLng(lat, lng),
	       map: map,
	    });
		
		//depricated object created to map routes with position names
		var bikeroutes = [
		  ['Downtown Orlando', 28.53834, -81.37924, 2],
		  ['Caddy Way Trail', 28.60741, -81.28865, 1]
		];     
	}
	  
	
	$('.toggle').bind('click',function(){
		var state = $(this).attr('rel');
		var $url = '../save_location.php';
		var $title = $('.trail_title').val();
		var $description = $('.trail_description').val();
		
		var $data = 'type='+ state + '&lng=' + lng + '&lat=' + lat + '&title=' + $title + '&description=' + $description;
		//Json object instead of ^		
		$.ajax({
			url: $url,
			data: $data,
			type: 'post',
			success: function(res){
				if(state == 'Start') {
					$('.toggle').attr('rel','Stop');
					$('.toggle').val('Stop');
				} else {
					$('.toggle').attr('rel','Start');
					$('.toggle').val('Start');	
				}
			}
		})
		return false;			
	})
	$('.usereditbtnarea').bind('click',function(){
		$('#edituserform').show();
		$('#edituserform').popup();
		$( "#edituserform").popup( "open" );
		 return false
	})
	
	$('.usereditcancel').bind('click',function(){
		$('#edituserform').popup('close');
		$('#edituserform').hide();
		return false;
	})
	
	$('.usereditsubmit').bind('click',function(){
		$('#edituserform').submit();
		return false;
	})
	
	//initialize();
})