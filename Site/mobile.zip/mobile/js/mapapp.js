$(document).ready(function(){
	/************** 
	lng: Longitude gps position
	lat: Latitude gps position
	timer: Future iteration variable for timing (maybe for ghostrunning)
	Type: Type is the stage which the application is going through
	points: Takes all the points passed and pushes them to an array
	map: easier returning of the map information in future iteration.
	 **************/
	var lng = '';
	var lat = '';
	var timer;
	var type = 'start';
	var points = [];
	var map = '';
	
	navigator.geolocation.getCurrentPosition(init_position);
	
	function init_position($pos) {
		lng = $pos.coords.longitude;
		lat = $pos.coords.latitude;
		if($('#currentposition').length>0){
			userpagemap();
		} else {
			createMap();
		}
	}
	/************** Calls the map api passing mapOptions to set default settings for map. **************/
	function createMap(){
		 var mapOptions = {
      		center: new google.maps.LatLng(lat,lng),
     		zoom: 18,
      		mapTypeId: google.maps.MapTypeId.ROADMAP
    	};
    
		map = new google.maps.Map(document.getElementById("appmap"),
        	mapOptions);
		
		var marker = new google.maps.Marker({    
       		position: new google.maps.LatLng(lat, lng),
       		map: map,
    	});
	}
	
	function add_point($coords) {
			points.push($coords);
			update_trail();
		}
		
	function update_trail(){
		var flightPlanCoordinates = [new google.maps.LatLng()];
						
		for(point in points) {
			flightPlanCoordinates.push(new google.maps.LatLng(points[point][0],points[point][1]));
		}
		
		var flightPath = new google.maps.Polyline({
			path: flightPlanCoordinates,
			strokeColor: '#FF0000',
			strokeOpacity: 1.0,
			strokeWeight: 2
		});
		
		flightPath.setMap(map);	
	}
	/************** Userpage Edit Form Modal **************/
	
	$('.usereditbtnarea').bind('click',function(){
		$('#edituserwrap').modal('show');
		 return false
	})
	
	$('.usereditcancel').bind('click',function(){
		$('.modal').modal('hide');
	})
	
	$('.usereditsubmit').bind('click',function(){
		$('#edituserform').submit();
		return false;
	})
				
	/********* Gets user's current location *********/
	function get_location($type) {
	   var callback = '';
	   if($type == 'start') {
	   	$callback = start_clock;
	   } else if($type == 'stop') {
	   	$callback = stop_clock;
	   } else if($type == 'ping') {
	   	$callback = ping_clock;
	   }
	   if($type != 'ping'){
	   	 navigator.geolocation.getCurrentPosition($callback);
	   }else{
	   		alert('Get_location -> else');
	   		 var options = {timeout:180000};
		     geoLoc = navigator.geolocation;
		     watchID = geoLoc.watchPosition($callback, 
		                                     errorHandler,
		                                     options);
	   }
	}
	function errorHandler(){
		// var noty = noty({text: 'noty - a jquery notification library!'});
	}
	
	/********* Grabs first location  *********/
	function start_clock(position) {
		var latitude = position.coords.latitude;
		var longitude = position.coords.longitude;
		$('.toggle_btn').val('stop');
		$('.toggle_btn').attr('rel','stop');
		$('.start').html('<br>Latitude: ' + latitude + '<br> Longitude: ' + longitude);
		start_timer();
	}
	/************** Saves current point to database **************/
	function save_point($data) {
		$.ajax({
			url:'/mobile/save_location.php',
			type:'POST',
			data:'longitude='+ $data.longitude + '&latitude=' + $data.latitude + '&type=' + $data.type,
			success:function(res){
				res = $.parseJSON(res);
				if(type == 'start'){
					type = 'ping';
				}
				$('.trailid').val(res.trail_id);
				$('.appmiles').html(res.distance + '<br> miles');
			
			}
		});
	}
	/************** Takes current ping location and passes it to save_point() **************/
	function ping_clock(position) {
		
		$('.apptoggle').removeAttr('disabled');
		var latitude = position.coords.latitude;
		var longitude = position.coords.longitude;
		var $data = {};
		
		$data.longitude = longitude;
		$data.latitude 	= latitude;
		$data.type 		= type;
		
		save_point($data);
		add_point([latitude,longitude]);	
	}
	
	function stop_clock() {
		type = 'stop';
		var $trail_id = $('.trailid').val();
		var $data = {};
		
		$data.longitude = lng;
		$data.latitude 	= lat;
		$data.type 		= type;
				
		save_point($data);
		
		
		/************** Application page functionality handling timeouts **************/
		
		$('.apptoggle').hide();
		$('#mapsave').show();
		//window.location.href ='/mobile/test.php';
	}

	$('.apptoggle').bind('click',function(){

		
		if($(this).attr('rel')=='start'){
/* 			$('.apptoggle').val('stop'); */
			$('.apptoggle').html('Stop');
			$('.apptoggle').attr('disabled','disabled');
			$('.apptoggle').attr('rel','stop');
			$('.apptoggle').addClass('redbtn');
			
			
		 var options = {timeout:500000};
		     geoLoc = navigator.geolocation;
		     watchID = geoLoc.watchPosition(ping_clock, 
		                                     errorHandler,
		                                     options);
		} else {
			navigator.geolocation.clearWatch(watchID);
			stop_clock();
			$('.apptoggle').html('Start');
			$('.apptoggle').attr('rel','start');
		}
		return false;
	})
	/************** Application page iteration changer **************/
	
		$('.riteration').bind('click', function(){
			
			
			if($('.riteration').attr('rel')=='start'){
				$('.rnew').hide();
				$('.riteration').attr('rel','old');
				$('.itselect').show();
				$('.riteration').html('Back to form');
				$('.rflag').val('1');
			}else{
				$('.rnew').show();
				$('.riteration').attr('rel','start');
				$('.itselect').hide();
				$('.riteration').html('Past Routes');
				$('.rflag').val('0');
			}
		})
	
	/************** MAP FOR USERPAGE **************/
	
	function userpagemap(){
	
		$('#currentposition').html('<img src="http://maps.googleapis.com/maps/api/staticmap?center='+lat+','+lng+'&zoom=18&size=1500x300&sensor=true&markers=color:red%7Clabel:User%7C'+lat+','+lng+'">')
			}
})

/************** Contact us form display **************/
$('.contactbtn').bind('click', function(){
	$('#contactwrap').modal('show');
	return false	
})

$('.contactcancel').bind('click',function(){
		$('.modal').modal('hide');
	})
	
$('.contactsubmit').bind('click',function(){
		$('#edituserform').submit();
		return false;
})

/************** TERMS OF SERVICE DISPLAY **************/
$('.termsbtn').bind('click', function(){
	$('#termswrap').modal('show');
	return false	
})

$('.termscancel').bind('click',function(){
		$('.modal').modal('hide');
	})
	

/************** Actions for userpage link **************/

$('.ufriends').bind('click',function(){
	$('#ufriendswrap').modal('show');
	 return false
})

$('.uroutes').bind('click',function(){
	$('#urouteswrap').modal('show');
	 return false
})
$('.uadd').bind('click',function(){
	var userid1 = $('.userid1').val();
	var userid2 = $('.userid2').val();
	
	var $url = '/mobile/add_friend.php';
	var $data = 'userid1=' + userid1 + '&userid2=' + userid2;
	
	$.ajax({
		'url': $url,
		'data': $data,
		'type': 'post',
		'success': function(res){
			$('.uadd').html('<span class="userconfirm">' + res + '</span>');
		}
	})
	return false;
})

$('#edituserform').bind('submit',function(){
	var $url,$data,$type;
	
	$url = '/mobile/check_userinfo.php';
	$data = $(this).serialize();

	$type = 'post';
	
	$.ajax({
		url: $url,
		type: $type,
		data: $data,
		async: false,
		success: function(res) {
			res = $.parseJSON(res);
			$ret = 'true';
			if(res.error) {
				var n = noty({text: res.error,timeout: 500});
				$ret = 'false';
			} 
		}
	})
	
	if($ret == 'false') {
		return false;
	}
})

$('.mapsaveform').bind('submit',function(){
	var $url,$data,$type;
	
	$url = '/mobile/check_mapinfo.php';
	$data = $(this).serialize();
	$type = 'post';
	
	$.ajax({
		url: $url,
		type: $type,
		data: $data,
		async: false,
		success: function(res) {
			res = $.parseJSON(res);
			$ret = 'true';
			if(res.error) {
				var n = noty({text: res.error,timeout: 500});
				$ret = 'false';
			} 
		}
	})
	
	if($ret == 'false') {
		return false;
	}
})