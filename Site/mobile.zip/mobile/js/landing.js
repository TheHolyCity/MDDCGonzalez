$(document).ready(function(){
		
	$('.signinbox').bind('submit',function(){		
		var $url,$data,$type;
		
		$url = '/mobile/check_login.php';
		$data = $(this).serialize();
		$type = 'post';
		
		$.ajax({
			url: $url,
			type: $type,
			data: $data,
			async: false,
			success: function(res) {
				res = $.parseJSON(res);
				if(res.error) {
					var n = noty({text: res.error,timeout: 1500});
					$ret = 'false';
				} 
				
				if(res.success) {
					$ret = 'true';
				}
	
			}
		})
			
		if($ret == 'false') {
			return false;
		}
	})
	
	$('.signupbox').bind('submit',function(){
		var $url,$data,$type;
		
		$url = '/mobile/check_register.php';
		$data = $(this).serialize();
		$type = 'post';
		
		$.ajax({
			url: $url,
			type: $type,
			data: $data,
			async: false,
			success: function(res) {
				res = $.parseJSON(res);
				$ret = 'true';
				if(res.error) {
					var n = noty({text: res.error,timeout: 1500});
					$ret = 'false';
				} 
			}
		})
		
		if($ret == 'false') {
			return false;
		}
	})
})