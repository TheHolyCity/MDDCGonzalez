<?php
	error_reporting(0);
	session_start();
	
	$link = mysql_connect('localhost','root','root');
	mysql_select_db('mobile',$link);
	
	$errors = $ret = array();
	
	extract($_POST);
	
	if(!$rname) {
		$errors[] = "Route name is required";
	}
	
	if(!$rdesc) {
		$errors[] = "Route description is required";
	}
	
	if($errors) {
		$ret['error'] = implode('<br>',$errors);
	} else {
		$ret['success'] = true;
	}
	
	echo json_encode($ret);
	exit;
?>