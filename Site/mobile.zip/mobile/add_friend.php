<?php
	error_reporting(0);
	session_start();
	
	$link = mysql_connect('localhost','root','root');
	mysql_select_db('mobile',$link);
	
	$userid1 = $_POST['userid1'];
	$userid2 = $_POST['userid2'];
	
	$sql = "INSERT INTO friends (userid1,userid2) VALUES ('$userid1','$userid2')";
	$query = mysql_query($sql) or die(mysql_error());
	
	echo 'Friend Added!';
	
?>