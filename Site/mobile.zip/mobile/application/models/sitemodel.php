<?php
class Sitemodel extends CI_Model{
	
	public function checklogin($email,$password){
		$password = md5($password);
		$query = $this->db->query("SELECT * from users WHERE password = '$password' AND email = '$email'");
		$this->load->library('session');
		if($query->num_rows()){
			$result = $query->result();
			$result = $result[0];
			$this->session->set_userdata($result);
			return true;
		}else{
			return false;
		}
	}
	public function updateuser($data){
		$this->load->database();
		$data['password'] = md5($data['password']);
		$query = $this->db->query("UPDATE users set  username = '$data[username]', password = '$data[password]', biography = '$data[biography]' where id = '$data[id]'");
	}
	
	public function app_detail_submit(){}
	public function add_friend(){}
	public function remove_friend(){}
	public function report(){}

}
?>