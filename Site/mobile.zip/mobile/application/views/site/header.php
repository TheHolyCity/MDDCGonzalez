<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		 <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="css/web.min.css" media="screen" />
		<link rel="stylesheet" href="font/rockwell/stylesheet.css" media="screen" />
		<script src="<?=base_url()?>js/jquery.js"></script>
		<script src="<?=base_url()?>bootstrap/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/jquery.noty.js"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/layouts/top.js"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/layouts/topLeft.js"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/layouts/topRight.js"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/themes/default.js"></script>
		<script src="<?=base_url()?>js/landing.min.js"></script>
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBuL-tWUHYx26WSntf8-DwHKepRgxNEGqk&sensor=true"></script>		<title>Out.Spoken GPS Web Application</title>
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<div id="branding"></div>
			</div>
