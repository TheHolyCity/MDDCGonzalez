<style>	
	#appwrap {
	    margin: 18px auto 0;
	    padding-top: 11px;
	    width: 543px;
	}
	
	#appwrap .apptoggle {
		background-color: #41A648;
	    color: #FFFFFF;
	    display: block;
	    font-size: 2.5em;
	    height: 10%;
	    line-height: 110%;
	    margin-left: auto;
	    margin-right: auto;
	    margin-top: 0;
	    text-align: center;
	    text-decoration: none;
	    width: 300px;
	    margin-top:10px;
	    margin-bottom: 15px;
	    padding:12px 0;
	}
	
	.appmiles {
		background: none repeat scroll 0 0 #FFFFFF;
	    display: block;
	    float: left;
	    font-size: 4.5em;
	    height: 211px;
	    line-height: 1em;
	    padding-top: 89px;
	    text-align: center;
	    width: 278px;
	}
	
	#appmap {
		background-color: #E5E3DF;
	    float: right;
	    margin: 0 auto;
	    overflow: hidden;
	    position: relative;
	    width: 259px;
	}
	
	.mapsaveform input { width: auto;}
	
	#mapsave {
		width: 44%;
		margin: 0 auto;
	}
	
</style>
<div class="clear"></div>
<div id="content">
	<div id="appview">
		<div id="topgear"></div>
		<div id="appwrap">
			<h3><?=$info->name?></h3>
			<p class="appmiles"><?=$info->distance?><br>miles</p>
			<div id="appmap"></div>
		</div>
	<div id="botgear"></div>
</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
	  
	    var myLatLng = new google.maps.LatLng('<?=$point[0]->lat?>', '<?=$point[0]->lng?>');
	    var mapOptions = {
	      zoom: 3,
	      center: myLatLng,
	      mapTypeId: google.maps.MapTypeId.TERRAIN
	    };
	
	    var map = new google.maps.Map(document.getElementById('appmap'), mapOptions);
	
	    var flightPlanCoordinates = [
	    	<?php
	    		foreach($points as $point) {
	    	?>
	    		new google.maps.LatLng('<?=$point->lat?>','<?=$point->lng?>'),
	    	<?
	    		}
	    	?>
	    ];
	    var flightPath = new google.maps.Polyline({
	      path: flightPlanCoordinates,
	      strokeColor: '#FF0000',
	      strokeOpacity: 1.0,
	      strokeWeight: 2
	    });
	
	    flightPath.setMap(map);

  })
</script>