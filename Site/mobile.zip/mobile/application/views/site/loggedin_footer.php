<div id="footer">
			</div>
		</div>
	<script src="<?=base_url()?>js/jquery.js"></script>
	<script src="<?=base_url()?>js/jquerym.js"></script>
	<script src="<?=base_url()?>bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBuL-tWUHYx26WSntf8-DwHKepRgxNEGqk&sensor=true"></script>
	<script type="text/javascript" src="<?=base_url()?>js/mapapp.js"></script>
	
	</body>
</html>