
<div id="footer">
	<p class="copyright"> Copyright &copy; 2013 <strong class="orange">Out.Spoken</strong> All rights reserved</p>
			</div>
		</div>
	<script type="text/javascript" src="<?=base_url()?>js/mapapp.min.js"></script>
	
	</body>
</html>