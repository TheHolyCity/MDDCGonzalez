<div id="subnav" class="red rw">
	<ul id="subnavbtns">
		<li><a href="<?=base_url()?>index.php/site/userview"><?=$username?></a></li>
		<li><a href="<?=base_url()?>index.php/site/app">Route Tracker</a></li>
		<li><a href="<?=base_url()?>index.php/site/contactus">Contact Us</a></li>
		<li><a href="<?=base_url()?>index.php/site/logout">Logout</a></li>
	</ul>
</div>