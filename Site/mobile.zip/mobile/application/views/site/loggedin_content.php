			<div id="content">
				<div id="herobox">
					<div id="bestroute"></div>
					<div class="routeinfo">
						<p class="infotitle">Newest Route: <span class="red rw">Titlehere</span></p>
						<p class="infomiles">Miles: <span class="red rw">Mileshere</span></p>
						<a href="" class="usereditbtn"><div class='usereditbtnarea'>Edit</div></a>
						<div class="clear"></div>
				</div>
				<div id="userbioarea">
						<p class="userbio brown rw"><?=$biography?></p>
				</div>
				<div id="edituserwrap">
					<form id="edituserform" action="<?=base_url()?>index.php/site/edituser" method="post">
						<input type="text" name="username" placeholder="Username" value="<?=$username?>" />
						<textarea name="biography" placeholder="biography"><?=$biography?></textarea>
						<input type="password" name="password" placeholder="Password">
						<input type="password" name="repassword" placeholder="Retype Password">
						<a class="usereditsubmit" href="#">Submit</a>
						&nbsp;
						<a class="usereditcancel" href="#">Close</a>
					</form>
				</div>
			</div>
			<a href="#" class="ufriends"> <span class="userlinktext">Friends</span> </a>
			<a href="#" class="uroutes"> <span class="userlinktext"> Routes</span> </a>
			<a href="#" class="uadd"> <span class="userlinktext"> Add +</span> </a>

<!--  <div id="content">
				<form>
					<input type="text" class="trail_title" placeholder="<?=$username?>">
					<textarea class="trail_description">
					</textarea>
					
					<div id="mapcontainer">
						<a href="<?=base_url()?>index.php/site/logout">Logout</a>
					 	<div id="map_canvas" style="width:400px; height:400px;"></div>
					</div>
				
					<input type="submit" name="submit" value="Start" class="btn btn-inverse toggle" rel="start" />
				</form>
			</div>
			
			
-->
