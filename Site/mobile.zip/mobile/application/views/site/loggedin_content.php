			<div id="content">
				<div id="herobox">
					<div id="currentposition"></div>
					<div id="userbioarea">
						<p class="usernamebio"><span>Username: </span><?=$username?></p>
						<p class="userbio brown rw"><?=$biography?></p>
					</div>
					<div class="routeinfo">
						<?php
							if($logged_in) {
						?>
						<a href="#edituserwrap" class="usereditbtn" data-toggle="modal"><div class='usereditbtnarea'>Edit</div></a>
						<? } ?>
						<div class="clear"></div>
				</div>
					<div id="edituserwrap" role="dialog" class="modal hide fade" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-header">
							<h3 id="myModalLabel">Edit Information</h3>
			    	   	</div>
			    	   	<div class="modal-body">
				    	   	 <form id="edituserform" action="<?=base_url()?>index.php/site/edituser" method="post">
	   							<input type="text" name="username" placeholder="Username" value="<?=$username?>"/>
								<textarea name="biography" placeholder="biography"><?=$biography?></textarea>
								<input type="password" name="password" placeholder="Password">
								<input type="password" name="repassword" placeholder="Retype Password">
							</form>
						</div>
					
						<div class="modal-footer">
							<a href="#" class="btn usereditcancel">Close</a>
							<a href="#" class="btn btn-primary usereditsubmit">Save changes</a>
						</div>
   				</div>
			</div>
			<a href="#" class="ufriends"> <span class="userlinktext">Friends</span> </a>
				
				<div id="ufriendswrap" role="dialog" class="modal hide fade" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-header">
							<h3 id="myModalLabel">Friends</h3>
			    	   	</div>
			    	   	<div class="modal-body">
			    	   		<div id="friendswrap">
			    	   			<?
									if($friends) {
										echo '<ul>';
										foreach($friends as $fri){
											echo '<li class="friend rw">';
												echo $fri->username;
											echo '</li>';
										}
										echo '</ul>';
									} else {
										echo '<p>You have no friends</p>';
									}
								?>
			    	   		</div>
			    	   	</div>
						<div class="modal-footer">
						</div>
   				</div>

			<a href="#" class="uroutes"> <span class="userlinktext"> Routes</span> </a>
				<div id="urouteswrap" role="dialog" class="modal hide fade" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-header">
							<h3 id="myModalLabel">Routes</h3>
			    	   	</div>
			    	   	<div class="modal-body">
			    	   		<div id="routeswrap">
			    	   			<?
									if($routes) {
										echo '<ul>';
										foreach($routes as $route){
											echo '<li class="friend rw">';
												echo '<a href="' . base_url() . '/index.php/site/route?id=' . $route->id . '">' . $route->name . '</a>';
											echo '</li>';
										}
										echo '</ul>';
									} else {
										echo '<p>You have no saved routes</p>';
									}
								?>
			    	   		</div>
			    	   	</div>
						<div class="modal-footer">
						</div>
   				</div>
   				
			<?php if(!$logged_in) {?>
			<a href="#" class="uadd"> <span class="userlinktext"> Add +</span> </a>
			<input type="hidden" class="userid2" value="<?=$id?>" />
			<? } ?>
			<input type="hidden" class="userid1" value="<?=$logged_in_id?>" />
				<div id="uaddwrap" role="dialog" class="modal hide fade" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-header"><h3 id="myModalLabel">Add Link</h3></div>
			    	   	<div class="modal-body"><div id="friendswrap"></div></div>
						<div class="modal-footer"></div>
   				</div>

<!--  <div id="content">
				<form>
					<input type="text" class="trail_title" placeholder="<?=$username?>">
					<textarea class="trail_description">
					</textarea>
					
					<div id="mapcontainer">
						<a href="<?=base_url()?>index.php/site/logout">Logout</a>
					 	<div id="map_canvas" style="width:400px; height:400px;"></div>
					</div>
				
					<input type="submit" name="submit" value="Start" class="btn btn-inverse toggle" rel="start" />
				</form>
			</div>
-->