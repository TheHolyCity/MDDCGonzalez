<div id="content">
	<div class="accordion" id="routelist">
		<div class="accordion-group">
			<div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#routelist" href="#collapseOne">
					Yolo
				</a>
			</div>
			<div id="collapseOne" class="accordion-body collapse in">
				<div class="accordion-inner">
        			Anim pariatur cliche...
      			</div>
			</div>
		</div>
	</div>
</div>