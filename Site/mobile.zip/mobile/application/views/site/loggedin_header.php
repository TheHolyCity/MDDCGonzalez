<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/web.min.css" media="screen" />
		<link rel="stylesheet" href="<?=base_url()?>font/rockwell/stylesheet.css" media="screen" />
		<link rel="stylesheet" href="<?=base_url()?>bootstrap/css/bootstrap.min.css" media="screen" />
		<script type="text/javascript" src="<?=base_url()?>js/jquery.js"></script>
		<script type="text/javascript" src="<?=base_url()?>bootstrap/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBuL-tWUHYx26WSntf8-DwHKepRgxNEGqk&sensor=true"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/jquery.noty.js"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/layouts/top.js"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/layouts/topLeft.js"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/layouts/topRight.js"></script>
		<script type="text/javascript" src="<?=base_url()?>js/noty/themes/default.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<title>Out.Spoken GPS Web Application</title>
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<div id="branding"></div>
				<div class="logoutbtn"></div>
			</div>