<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="<?=base_url()?>css/web.css" media="screen" />
		<link rel="stylesheet" href="<?=base_url()?>font/rockwell/stylesheet.css" media="screen" />
		<link rel="stylesheet" href="<?=base_url()?>bootstrap/css/bootstrap.min.css" media="screen" />
		<link rel="stylesheet" href="<?=base_url()?>css/jquerym.min.css" media="screen" />
		<title>Out.Spoken GPS Web Application</title>
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<div id="branding"></div>
				<div class="logoutbtn"></div>
			</div>