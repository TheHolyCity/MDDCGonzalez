<div class="clear"></div>
<div id="content">
	<div id="appview">
		<div id="topgear"></div>
		<div id="appwrap">
			<div id="mapsave" style="display:none;">
				<form method="post" action="<?=base_url()?>index.php/site/save_route" class="mapsaveform">
					<select class="itselect" style="display:none;">
					<? foreach($routes as $res){
						echo '<option value='.$res->id.'>'.$res->name.'</option>';
					}?>
					</select>
					<input class="rflag" type="hidden" name="rflag" value="0">
					<input class='rnew' type="text" name="rname" placeholder="Route Name">
					<a href="#" class="riteration" rel="start">Past Routes</a><br/>
					<input class='rnew' type="text" name="rtag" placeholder="Tags IE(#Nature, #Urban)">
					<input class='rnew'  name="rdist" type="hidden" value=""> <!-- Calculate Miles between pings --> 
					<textarea class='rnew' name="rdesc" placeholder="Route Description"></textarea><br/>
					<input class="trailid" name="trailid" type="hidden" value="<?=$trailid?>"> <!-- Get trailid from session --> 
					<input class="mapsavebtn rw" type="submit" name="rsavebtn" value="Submit">
					<div class="clear"></div>
				</form>
			</div>
			<a href="#" class="apptoggle rw" rel="start">Start</a>
			<p class="appmiles">0<br>miles</p>
			<div id="appmap"></div>
			
		</div>
	<div id="botgear"></div>
</div>
</div>
