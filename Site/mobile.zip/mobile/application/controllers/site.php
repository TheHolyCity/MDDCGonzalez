<?php  if( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Site extends CI_Controller{
		public function index(){
				$this->home();
			}
		public function protect(){
			$this->load->library('session');
			if(!$this->session->userdata('id')){
				redirect(base_url());
			}
		}
		public function home(){
				$this->load->model('sitemodel');
				$this->load->library('form_validation');
				$this->load->view('site/header');
				$this->load->view('site/content_landing');
				$this->load->view('site/footer');
		}

		public function register(){
			$this->load->library('form_validation');
			$this->load->model('sitemodel');
						
			$this->form_validation->set_rules("username", "Username", 'required');
			$this->form_validation->set_rules("email", "Email", 'required');
			$this->form_validation->set_rules("password", "Password", 'required|matches[repassword]');
			$this->form_validation->set_rules("repassword", "Retype Password", 'required');
			
			
			if(! $this->form_validation->run()){
					$this->home();
				}else{
					$data = array('username'=>set_value('username'),'password'=> md5(set_value('password')),'email'=>set_value('email'));
					$sql = $this->db->insert_string('users', $data);
					$this->db->query($sql);
					$this->session->set_userdata($data);
					redirect('site/userview',$data);
					
			}
			
		}
		//Edit 
		public function edituser(){
			$this->protect();
			$data = array("id" => $this->session->userdata("id"),
							"username" => $_POST["username"],
							"biography" => $_POST["biography"],
							"password" => $_POST["password"]);
			$this->load->library('form_validation');
			$this->load->model('sitemodel');
			$this->sitemodel->updateuser($data);
			
			$this->session->set_userdata($data);
			redirect('site/userview');
			
			//$this->load->view("site/edituser");
			
		}
		
		public function userview(){
			$this->protect();
			$this->load->library('session');			
			$data = array('username' => $this->session->userdata('username'),
						  'email' => $this->session->userdata('email'),
						  'biography' => $this->session->userdata('biography'));
			
			$this->load->view('site/loggedin_header');
			$this->load->view('site/loggedin_subnav',$data);
			$this->load->view('site/loggedin_content',$data);
			$this->load->view('site/loggedin_footer');
			
		}

		public function appview(){
			$this->protect();
			$this->load->model('sitemodel');
			
		}
		public function routeview(){
		
		}
		
		public function app(){
		
		}
		
		public function all_users(){
		
		}
		public function friends(){
		
		}
		public function app_detail(){
		
		}
		public function app_detail_submit(){
		
		}
		public function add_friend(){
		
		}
		public function remove_friend(){
		
		}
		public function report(){}
		
		public function login(){
			
			$this->load->library('form_validation');
			$this->load->model('sitemodel');
			
			$this->form_validation->set_rules("email", "email", 'required');
			$this->form_validation->set_rules("password", "password", 'required');
			if(! $this->form_validation->run()){
				$this->home();	
			}else{
				$email = set_value('email');
				$password = set_value('password');
				if($this->sitemodel->checklogin($email,$password)){
					redirect('site/userview');
						
				}else{
					$this->session->set_flashdata('login', 'Login information is incorrect');
					$this->home();
					redirect(base_url(),'refresh');
				}
			}
		}
		public function logout() {
			$this->session->sess_destroy();
			redirect(base_url(),'refresh');
		}
		
	}
?>