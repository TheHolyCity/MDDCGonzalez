<?php
	error_reporting(0);
	session_start();
	
	$link = mysql_connect('localhost','root','root');
	mysql_select_db('mobile',$link);
	
	/************** Distance formula between two points **************/
	function getDistance($latitude1, $longitude1, $latitude2, $longitude2) {
	    $theta = $longitude1 - $longitude2;
	    $miles = (sin(deg2rad($latitude1)) * sin(deg2rad($latitude2))) + (cos(deg2rad($latitude1)) * cos(deg2rad($latitude2)) * cos(deg2rad($theta)));
	    $miles = acos($miles);
	    $miles = rad2deg($miles);
	    $miles = $miles * 60 * 1.1515;
	    $feet = $miles * 5280;
	    $yards = $feet / 3;
	    $kilometers = $miles * 1.609344;
	    $meters = $kilometers * 1000;
	    return $miles;
	    return compact('miles','feet','yards','kilometers','meters'); 
	}
	
	$type = $_POST['type'];
	$lng = $_POST['longitude'];
	$lat = $_POST['latitude'];
	$type = $_POST['type'];
	$title = $_POST['title'];
	$description = $_POST['description'];
	$trail_id = '';
	$type = strtolower($type);
	
	/************** Determine if this is an active trail, or a new one **************/
	if($type == 'start') {
		$sql = "INSERT INTO trails (name) VALUES ('$title')";
		$query = mysql_query($sql) or die(mysql_error());
		$trail_id = mysql_insert_id();
		$_SESSION['last_trail_id'] = $trail_id;
	} else {
		$trail_id = $_SESSION['last_trail_id'];
	}
	
	$last_point = array();
	$distance = 0;
	
	
	/************** Calculate current distance **************/
	$sql = "SELECT * FROM points WHERE trail_id = $trail_id ORDER BY id ASC";
	$query = $query = mysql_query($sql) or die(mysql_error());
	if(mysql_num_rows($query)) {
		while($row = mysql_fetch_assoc($query)) {
			if($last_point) {				
				
				
				if(!(int)$row['lat'] || !(int)$row['lng'] || !(int)$last_point['lat'] || !(int)$last_point['lng']) {continue;}
						
				$d = getDistance($last_point['lat'],$last_point['lng'],$row['lat'],$row['lng']);
				$distance += $d;
			}
			$last_point = array();
			$last_point['lat'] = $row['lat'];
			$last_point['lng'] = $row['lng'];
		}
	}
	
	/************** Set Distance for trail **************/
	if($distance) {
	
		$sql = "UPDATE trails SET `distance` = '$distance' WHERE id = $trail_id";
		mysql_query($sql) or die(mysql_error());
	}
	
	/************** Insert user's current point **************/
	$sql = "INSERT INTO points (`lat`,`lng`,`trail_id`,`type`) VALUES ('$lat','$lng','$trail_id','$type')";
	$query = mysql_query($sql) or die(mysql_error());
	
	$ret = array(
		'trail_id' => $trail_id,
		'distance' => number_format($distance,2)
	);
	
	echo json_encode($ret);
?>